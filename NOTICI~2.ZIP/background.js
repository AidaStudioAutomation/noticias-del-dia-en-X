importScripts('shared.js'); // parseAccounts, sanitizeFileName, generateId, scheduleMatchesDay, DOW_LABELS

// ============================================================================
// ESTADO EN MEMORIA — solo describe el trabajo que se está ejecutando AHORA.
// Las listas, programaciones y preferencias viven en chrome.storage.local y
// las gestiona options.js; aquí solo se leen para ejecutar el trabajo.
// ============================================================================
function freshState() {
  return {
    active: false,
    finished: false,
    paused: false,
    stopped: false,
    dateFrom: '',
    dateTo: '',
    accounts: [],
    items: [],
    accumulated: '',   // cuerpo del informe (fragmentos txt o rtf ya construidos)
    headerText: '',    // cabecera del informe (título + metadatos)
    headlineItems: [], // tweets válidos encontrados hasta ahora, para el índice de titulares
    format: 'rtf',
    filename: '',
    statusText: '',
    jobLabel: '',       // p.ej. "Lista: Fútbol" o '' si es una extracción manual
    jobIndex: 0,
    jobTotal: 0,
    queueLength: 0
  };
}
let state = freshState();

let jobQueue = [];
let queueRunning = false;
let batchSummaries = {}; // batchId -> [{ listName, count, error }]

// ============================================================================
// Ventana de control: en vez del popup anclado al icono (que Chrome cierra en
// cuanto pierde el foco, por ejemplo al abrir una pestaña de X), al hacer clic
// en el icono se abre una ventana propia y pequeña que se queda abierta hasta
// que el usuario la cierra a mano. Así se puede dejar abierta y pulsar
// Pausar/Detener en cualquier momento, aunque haya otras pestañas activas.
// ============================================================================
let controlWindowId = null;

chrome.action.onClicked.addListener(() => { openControlWindow(); });

async function openControlWindow() {
  if (controlWindowId != null) {
    try {
      await chrome.windows.update(controlWindowId, { focused: true, state: 'normal' });
      return;
    } catch (e) {
      controlWindowId = null; // la ventana ya no existe; se crea una nueva abajo
    }
  }
  const win = await chrome.windows.create({
    url: chrome.runtime.getURL('popup.html'),
    type: 'popup',
    width: 780,
    height: 820
  });
  controlWindowId = win.id;
}

chrome.windows.onRemoved.addListener((id) => {
  if (id === controlWindowId) controlWindowId = null;
});

// ============================================================================
// Configuración remota (opcional): un archivo JSON público que TÚ controlas
// (por ejemplo, un Gist gratuito de GitHub — ver README) para avisar de
// nuevas versiones y, si hiciera falta, desactivar todas las copias a la vez.
// Si no configuras REMOTE_CONFIG_URL, o no hay internet, todo sigue funcionando
// con normalidad: nunca se bloquea nada por no poder comprobar esto ("fail-open").
//
// Formato esperado del JSON:
// {
//   "latestVersion": "2.1",
//   "downloadUrl": "https://tu-web-o-tienda.com/descarga",
//   "changelog": "Novedades de la última versión...",
//   "killSwitch": false,
//   "killMessage": "Texto que verá el usuario si activas el interruptor"
// }
// ============================================================================
const REMOTE_CONFIG_URL = ''; // pega aquí la URL "raw" de tu Gist cuando la tengas (ver README)
const REMOTE_CONFIG_CACHE_MS = 30 * 60 * 1000; // no comprobar más de una vez cada 30 min

// ============================================================================
// Prueba gratuita + suscripción. Todo el mundo puede usar la extensión entera
// durante TRIAL_USES búsquedas (cada pulsación de "Extraer noticias", cada
// ejecución manual de listas y cada búsqueda programada cuenta como un uso);
// a partir de ahí hace falta un código de activación válido para seguir
// usándola. El contador se guarda con chrome.storage.sync (no .local) para
// que, si alguien desinstala y vuelve a instalar con la misma cuenta de
// Google iniciada en Chrome, no se reinicie solo por eso.
//
// FRIEND_CODE es un código fijo que tú repartes a mano (compañeros, familia...)
// para darles acceso gratis sin pasar por ningún pago; cámbialo por el que
// quieras. Los LICENSE_CHECKOUT_URL_* son los enlaces de pago (uno por plan,
// de Lemon Squeezy, Gumroad, etc.) a los que se manda a quien elige cada
// plan en la pantalla de precios — pégalos aquí cuando los tengas (ver
// README, sección de venta). Mientras estén vacíos, el botón de ese plan
// avisa de que aún no está listo, pero el código de amigos funciona igual.
// ============================================================================
const TRIAL_USES = 3;
const FRIEND_CODE = 'COMPIS2026'; // cámbialo por el código que quieras repartir tú misma
const PLANS = [
  { id: 'monthly', label: '1 mes', price: '3€', per: '/mes', checkoutUrl: '', badge: '' },
  { id: 'quarterly', label: '3 meses', price: '7€', per: '/3 meses', checkoutUrl: '', badge: 'MÁS POPULAR' },
  { id: 'yearly', label: '1 año', price: '25€', per: '/año', checkoutUrl: '', badge: 'MEJOR VALOR' }
];

async function checkLicenseKey(key) {
  if (!key) return false;
  if (key.trim().toUpperCase() === FRIEND_CODE.toUpperCase()) return true;
  // TODO: cuando actives las ventas, valida aquí la clave contra la API de
  // licencias de Lemon Squeezy (o el servicio que uses) y devuelve true si es válida.
  return false;
}

async function isLicenseValid() {
  const data = await new Promise((r) => chrome.storage.sync.get(['xnews_usesCount', 'xnews_licenseKey'], r));
  const usesCount = data.xnews_usesCount || 0;
  const trialActive = usesCount < TRIAL_USES;
  const key = (data.xnews_licenseKey || '').trim();
  const hasPaidLicense = key ? await checkLicenseKey(key) : false;
  const usesLeft = Math.max(0, TRIAL_USES - usesCount);
  return { ok: trialActive || hasPaidLicense, trialActive, hasPaidLicense, usesLeft, usesCount };
}

// Se llama una sola vez por cada búsqueda que realmente arranca (no una vez
// por cuenta ni por lista): un uso = una pulsación de "Extraer", una
// ejecución manual de listas, o una búsqueda programada por una alarma.
async function incrementUsage() {
  const data = await new Promise((r) => chrome.storage.sync.get('xnews_usesCount', r));
  const next = (data.xnews_usesCount || 0) + 1;
  await new Promise((r) => chrome.storage.sync.set({ xnews_usesCount: next }, r));
}

async function fetchRemoteConfig() {
  if (!REMOTE_CONFIG_URL) return null;
  try {
    const res = await fetch(REMOTE_CONFIG_URL, { cache: 'no-store' });
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null; // sin internet, gist caído, etc.: se ignora, no se bloquea nada
  }
}

async function getRemoteConfig() {
  const cached = await new Promise((r) => chrome.storage.local.get('xnews_remote_config', (d) => r(d.xnews_remote_config)));
  const now = Date.now();
  if (cached && (now - cached.checkedAt) < REMOTE_CONFIG_CACHE_MS) return cached.data;
  const fresh = await fetchRemoteConfig();
  if (fresh) {
    await new Promise((r) => chrome.storage.local.set({ xnews_remote_config: { data: fresh, checkedAt: now } }, r));
    return fresh;
  }
  return cached ? cached.data : null;
}

// ============================================================================
// Control de pausa/detención, compartido con el script inyectado en la pestaña.
// Se guarda en chrome.storage.local (no session): los scripts inyectados vía
// chrome.scripting.executeScript corren en un "mundo aislado" que SÍ puede leer
// storage.local sin configuración extra, a diferencia de storage.session.
// ============================================================================
function getControl() {
  return new Promise((resolve) => {
    chrome.storage.local.get('xnews_control', (data) => resolve(data.xnews_control || { stop: false, pause: false }));
  });
}
function setControl(patch) {
  return getControl().then((c) => new Promise((resolve) => {
    const next = { ...c, ...patch };
    chrome.storage.local.set({ xnews_control: next }, () => resolve(next));
  }));
}
async function waitIfPaused() {
  let c = await getControl();
  let notified = false;
  while (c.pause && !c.stop) {
    if (!notified) { setStatus('Pausado. Pulsa "Reanudar" para continuar.'); notified = true; }
    await sleep(400);
    c = await getControl();
  }
  return c;
}

function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get('xnews_settings', (data) =>
      resolve(Object.assign({ outputFormat: 'rtf', includeAiPrompt: true, includeReposts: true }, data.xnews_settings || {})));
  });
}
function getLists() {
  return new Promise((resolve) => chrome.storage.local.get('xnews_lists', (d) => resolve(d.xnews_lists || [])));
}
function getSchedules() {
  return new Promise((resolve) => chrome.storage.local.get('xnews_schedules', (d) => resolve(d.xnews_schedules || [])));
}
function saveSchedules(schedules) {
  return new Promise((resolve) => chrome.storage.local.set({ xnews_schedules: schedules }, resolve));
}

// ============================================================================
// Mensajería con popup.js y options.js
// ============================================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'START') {
    (async () => {
      const license = await isLicenseValid();
      if (!license.ok) { sendResponse({ ok: false, licenseRequired: true }); return; }
      await incrementUsage();
      if (msg.mode === 'keyword') {
        enqueueJobs([{
          mode: 'keyword',
          keyword: msg.keyword,
          dateFrom: msg.dateFrom,
          dateTo: msg.dateTo || msg.dateFrom,
          fileBase: `Busqueda_${sanitizeFileName(msg.keyword)}_`,
          jobLabel: `Búsqueda: "${msg.keyword}"`,
          jobIndex: 1,
          jobTotal: 1
        }]);
      } else {
        enqueueJobs([{
          mode: 'accounts',
          accounts: msg.accounts,
          dateFrom: msg.dateFrom,
          dateTo: msg.dateTo || msg.dateFrom,
          fileBase: msg.listName ? `Noticias_${sanitizeFileName(msg.listName)}_` : 'NoticiasHoy',
          jobLabel: msg.listName ? `Lista: ${msg.listName}` : '',
          jobIndex: 1,
          jobTotal: 1
        }]);
      }
      sendResponse({ ok: true });
    })();
    return true;
  } else if (msg.type === 'CHECK_LICENSE') {
    isLicenseValid().then((license) => {
      sendResponse(Object.assign({}, license, { plans: PLANS }));
    });
    return true;
  } else if (msg.type === 'ACTIVATE_LICENSE') {
    (async () => {
      const key = (msg.key || '').trim();
      if (!key) { sendResponse({ ok: false, note: 'Escribe un código.' }); return; }
      const valid = await checkLicenseKey(key);
      if (valid) {
        await new Promise((r) => chrome.storage.sync.set({ xnews_licenseKey: key }, r));
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, note: 'Ese código no es válido. Revisa que esté bien escrito.' });
      }
    })();
    return true;
  } else if (msg.type === 'GET_STATE') {
    state.queueLength = jobQueue.length;
    sendResponse(state);
  } else if (msg.type === 'RESET') {
    state = freshState();
    setControl({ stop: false, pause: false });
  } else if (msg.type === 'STOP') {
    jobQueue = []; // detener cancela también el resto de la cola (p.ej. otras listas de la misma programación)
    setControl({ stop: true });
    setStatus('Deteniendo… (se detendrá en cuanto termine el paso actual)');
  } else if (msg.type === 'PAUSE_TOGGLE') {
    getControl().then((c) => {
      const paused = !c.pause;
      setControl({ pause: paused });
      state.paused = paused;
      broadcast({ type: 'PAUSE_STATE', paused });
      setStatus(paused ? 'Pausado. Pulsa "Reanudar" para continuar.' : 'Reanudado, continuando…');
    });
  } else if (msg.type === 'SYNC_ALARMS') {
    syncAlarms().then(() => sendResponse({ ok: true }));
    return true;
  } else if (msg.type === 'RUN_LISTS_NOW') {
    (async () => {
      const license = await isLicenseValid();
      if (!license.ok) { sendResponse({ ok: false, licenseRequired: true }); return; }
      const lists = await getLists();
      const chosen = lists.filter((l) => msg.listIds.includes(l.id));
      if (chosen.length === 0) { sendResponse({ ok: false, error: 'sin listas' }); return; }
      await incrementUsage();
      const dateStr = todayStr();
      const batchId = generateId();
      const jobs = chosen.map((list, idx) => ({
        mode: 'accounts',
        accounts: list.accounts,
        dateFrom: dateStr,
        dateTo: dateStr,
        fileBase: `Noticias_${sanitizeFileName(list.name)}_`,
        jobLabel: `Lista: ${list.name}`,
        jobIndex: idx + 1,
        jobTotal: chosen.length,
        batchId,
        batchLabel: chosen.length > 1 ? 'Ejecución manual de varias listas' : `Lista: ${chosen[0].name}`,
        isLastInBatch: idx === chosen.length - 1
      }));
      enqueueJobs(jobs);
      sendResponse({ ok: true, queued: jobs.length });
    })();
    return true;
  } else if (msg.type === 'OPEN_CONTROL_WINDOW') {
    openControlWindow();
  } else if (msg.type === 'CHECK_UPDATE') {
    (async () => {
      const cfg = await getRemoteConfig();
      const current = chrome.runtime.getManifest().version;
      const hasUpdate = !!(cfg && cfg.latestVersion && isNewerVersion(cfg.latestVersion, current));
      sendResponse({
        ok: true,
        current,
        hasUpdate,
        latest: cfg ? cfg.latestVersion : null,
        downloadUrl: cfg ? cfg.downloadUrl : null,
        changelog: cfg ? cfg.changelog : null,
        killed: !!(cfg && cfg.killSwitch),
        killMessage: cfg ? cfg.killMessage : null
      });
    })();
    return true;
  } else if (msg.type === 'RUN_DIAGNOSTIC') {
    runDiagnostic(msg.handle).then((result) => sendResponse(result));
    return true;
  }
  return true;
});

function broadcast(msg) { chrome.runtime.sendMessage(msg).catch(() => {}); }
function setStatus(text) { state.statusText = text; broadcast({ type: 'STATUS', statusText: text }); }
function updateItem(index) { broadcast({ type: 'ACCOUNT_UPDATE', index, item: state.items[index] }); }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
function markSkippedFrom(fromIndex, accounts) {
  for (let j = fromIndex; j < accounts.length; j++) {
    state.items[j] = { status: 'skipped', count: 0, note: '' };
    updateItem(j);
  }
}
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function toDisplayDate(dateStr) {
  // YYYY-MM-DD -> DD/MM/YYYY
  return `${dateStr.slice(8, 10)}/${dateStr.slice(5, 7)}/${dateStr.slice(0, 4)}`;
}
function toFileDate(dateStr) {
  // YYYY-MM-DD -> DDMMYYYY
  return `${dateStr.slice(8, 10)}${dateStr.slice(5, 7)}${dateStr.slice(0, 4)}`;
}
function rangeDisplay(dateFrom, dateTo) {
  return dateFrom === dateTo ? toDisplayDate(dateFrom) : `${toDisplayDate(dateFrom)} al ${toDisplayDate(dateTo)}`;
}
function rangeFileTag(dateFrom, dateTo) {
  return dateFrom === dateTo ? toFileDate(dateFrom) : `${toFileDate(dateFrom)}-${toFileDate(dateTo)}`;
}

// ============================================================================
// Cola de trabajos: cada trabajo = una lista de cuentas -> un archivo.
// Una programación con 3 listas encola 3 trabajos que se ejecutan uno detrás
// de otro (para no saturar X abriendo muchas pestañas a la vez).
// ============================================================================
function enqueueJobs(jobs) {
  jobQueue.push(...jobs);
  processQueue();
}

async function processQueue() {
  if (queueRunning) return;
  queueRunning = true;
  while (jobQueue.length > 0) {
    // Interruptor remoto: si está activado, no se abre ninguna pestaña ni se
    // gasta nada. Si no hay internet o no está configurado, esto no bloquea nada.
    const cfg = await getRemoteConfig();
    if (cfg && cfg.killSwitch) {
      const msg = cfg.killMessage || 'Esta copia de la extensión ha sido desactivada.';
      jobQueue = [];
      state.active = false;
      state.finished = true;
      setStatus(msg);
      broadcast({ type: 'ALL_DONE', statusText: msg });
      break;
    }
    // Prueba gratuita / suscripción: cubre también las búsquedas programadas
    // (alarmas) y "ejecutar ahora", que no pasan por el mensaje START.
    const license = await isLicenseValid();
    if (!license.ok) {
      const msg = 'Tu prueba gratuita ha terminado. Abre la extensión para activar tu suscripción.';
      jobQueue = [];
      state.active = false;
      state.finished = true;
      setStatus(msg);
      broadcast({ type: 'ALL_DONE', statusText: msg, licenseRequired: true });
      break;
    }

    const job = jobQueue.shift();
    state.queueLength = jobQueue.length;
    const result = await runOneJob(job);
    if (job.batchId) await handleBatchProgress(job, result);
  }
  queueRunning = false;
}

async function handleBatchProgress(job, result) {
  if (!batchSummaries[job.batchId]) batchSummaries[job.batchId] = [];
  batchSummaries[job.batchId].push(result);
  if (!job.isLastInBatch) return;

  const summaries = batchSummaries[job.batchId];
  delete batchSummaries[job.batchId];

  if (job.scheduleId) {
    const schedules = await getSchedules();
    const sch = schedules.find((s) => s.id === job.scheduleId);
    if (sch) {
      sch.lastRun = new Date().toISOString();
      sch.lastResult = summarizeBatch(summaries);
      await saveSchedules(schedules);
    }
  }

  notifyBatchDone(job.batchLabel || job.scheduleName || 'Extracción', summaries);
}

function summarizeBatch(summaries) {
  const parts = summaries.map((r) => `${r.listName}: ${r.text}`);
  return parts.join(' · ');
}

function notifyBatchDone(title, summaries) {
  const lines = summaries.map((r) => `${r.listName}: ${r.text}`);
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: `Noticias del Día en X — ${title}`,
    message: lines.join('\n').slice(0, 480)
  }, () => { /* si el usuario tiene notificaciones desactivadas, no pasa nada */ });
}

// ============================================================================
// chrome.alarms: una alarma por programación (xnews_sched_<id>). Al dispararse,
// se encolan los trabajos de las listas asociadas y se reprograma la siguiente
// aparición respetando los días de la semana elegidos.
// ============================================================================
function computeNextOccurrence(schedule, from) {
  const [hh, mm] = (schedule.time || '09:00').split(':').map(Number);
  for (let addDays = 0; addDays < 8; addDays++) {
    const d = new Date(from.getFullYear(), from.getMonth(), from.getDate() + addDays, hh, mm, 0, 0);
    if (d.getTime() <= from.getTime()) continue; // tiene que ser estrictamente futuro
    if (scheduleMatchesDay(schedule.days, d)) return d;
  }
  return new Date(from.getTime() + 24 * 60 * 60 * 1000); // fallback, no debería ocurrir
}

async function syncAlarms() {
  await chrome.alarms.clearAll();
  const schedules = await getSchedules();
  const now = new Date();
  for (const sch of schedules) {
    if (!sch.enabled) continue;
    if (!sch.listIds || sch.listIds.length === 0) continue;
    const next = computeNextOccurrence(sch, now);
    chrome.alarms.create(`xnews_sched_${sch.id}`, { when: next.getTime() });
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith('xnews_sched_')) return;
  const schedId = alarm.name.slice('xnews_sched_'.length);
  const schedules = await getSchedules();
  const sch = schedules.find((s) => s.id === schedId);
  if (!sch) return;

  if (sch.enabled && sch.listIds && sch.listIds.length > 0) {
    const license = await isLicenseValid();
    const lists = license.ok ? await getLists() : [];
    const chosen = lists.filter((l) => sch.listIds.includes(l.id));
    if (chosen.length > 0) {
      await incrementUsage();
      const dateStr = todayStr();
      const batchId = generateId();
      const jobs = chosen.map((list, idx) => ({
        mode: 'accounts',
        accounts: list.accounts,
        dateFrom: dateStr,
        dateTo: dateStr,
        fileBase: `Noticias_${sanitizeFileName(list.name)}_`,
        jobLabel: `Lista: ${list.name}`,
        jobIndex: idx + 1,
        jobTotal: chosen.length,
        scheduleId: sch.id,
        scheduleName: sch.name,
        batchLabel: `Programación: ${sch.name}`,
        batchId,
        isLastInBatch: idx === chosen.length - 1
      }));
      enqueueJobs(jobs);
    }
  }

  // Reprogramar la siguiente aparición de esta programación, exista trabajo o no.
  const next = computeNextOccurrence(sch, new Date());
  chrome.alarms.create(alarm.name, { when: next.getTime() });
});

chrome.runtime.onInstalled.addListener(() => { syncAlarms(); });
chrome.runtime.onStartup.addListener(() => { syncAlarms(); });

// ============================================================================
// Ejecución de UN trabajo (una lista de cuentas -> un archivo)
// ============================================================================
async function runOneJob(job) {
  await setControl({ stop: false, pause: false });

  const isKeyword = job.mode === 'keyword';
  const settings = await getSettings();
  const format = settings.outputFormat === 'txt' ? 'txt' : 'rtf';
  const ext = format === 'rtf' ? 'rtf' : 'txt';
  const disp = rangeDisplay(job.dateFrom, job.dateTo);
  const filename = `${job.fileBase}${rangeFileTag(job.dateFrom, job.dateTo)}.${ext}`;

  // En modo cuentas, "targets" son los @handles a visitar uno a uno.
  // En modo palabra clave, es un único elemento (la propia palabra), porque
  // se hace una sola búsqueda en x.com/search en vez de visitar varios perfiles.
  const targets = isKeyword ? [job.keyword] : job.accounts;

  state = {
    active: true,
    finished: false,
    paused: false,
    stopped: false,
    mode: job.mode || 'accounts',
    dateFrom: job.dateFrom,
    dateTo: job.dateTo,
    accounts: targets,
    items: targets.map(() => ({ status: 'pending', count: 0, note: '' })),
    accumulated: '',
    headlineItems: [],
    headerText: buildHeaderText(format, disp, job.accounts, job.jobLabel, isKeyword, job.keyword)
      + (settings.includeAiPrompt ? buildAiPromptBlock(format) : ''),
    format,
    filename,
    statusText: '',
    jobLabel: job.jobLabel || '',
    jobIndex: job.jobIndex || 1,
    jobTotal: job.jobTotal || 1,
    queueLength: jobQueue.length
  };
  broadcast({
    type: 'JOB_START',
    jobLabel: state.jobLabel, accounts: state.accounts, mode: state.mode,
    jobIndex: state.jobIndex, jobTotal: state.jobTotal
  });

  let totalTweets = 0;
  const jobNameForResult = () => (isKeyword ? `"${job.keyword}"` : (job.jobLabel || '').replace(/^Lista: /, '') || 'Manual');

  for (let i = 0; i < targets.length; i++) {
    const ctrlBefore = await waitIfPaused();
    if (ctrlBefore.stop) {
      markSkippedFrom(i, targets);
      await finishRun('Detenido por ti.', { partial: true });
      return { listName: jobNameForResult(), text: `detenido (${totalTweets} tweets)` };
    }

    const target = targets[i];
    state.items[i].status = 'working';
    updateItem(i);
    setStatus(isKeyword
      ? `Buscando "${target}"…`
      : `Revisando @${target} (${i + 1} de ${targets.length})…`);

    const res = await processAccount(target, job.dateFrom, job.dateTo, settings.includeReposts !== false, job.mode, job.keyword);

    if (res.error === 'login') {
      state.items[i] = { status: 'failed', count: 0, note: 'sin sesión en X' };
      updateItem(i);
      markSkippedFrom(i + 1, targets);
      jobQueue = []; // sin sesión, el resto de trabajos en cola fallarían igual: no merece la pena seguir
      await finishRun('Detenido: inicia sesión en x.com y vuelve a intentarlo.', {});
      return { listName: jobNameForResult(), text: 'sin sesión en X' };
    }

    // Solo se escribe en el archivo si hay tweets de verdad: nada de "sin tweets",
    // "cuenta no encontrada" ni otros avisos — eso queda solo en el progreso del popup.
    const hasContent = !res.error && res.tweets && res.tweets.length > 0;
    if (hasContent) {
      const labelOverride = isKeyword ? `Resultados de búsqueda: "${target}"` : null;
      state.accumulated += buildSectionText(format, target, disp, res, labelOverride);
      res.tweets.forEach((t) => {
        state.headlineItems.push({ handle: isKeyword ? `🔍 "${target}"` : `@${target}`, time: t.time, text: t.text, repost: t.repost });
      });
      await saveFile();
    }

    if (res.error) {
      state.items[i] = { status: 'failed', count: 0, note: res.errorNote || 'error' };
      updateItem(i);
    } else if (res.stoppedByUser) {
      totalTweets += res.tweets.length;
      state.items[i] = { status: 'done', count: res.tweets.length, note: 'detenido: parcial' };
      updateItem(i);
      markSkippedFrom(i + 1, targets);
      await finishRun('Detenido por ti.', {});
      return { listName: jobNameForResult(), text: `detenido (${totalTweets} tweets)` };
    } else {
      totalTweets += res.tweets.length;
      state.items[i] = { status: 'done', count: res.tweets.length, note: '' };
      updateItem(i);
    }

    await sleep(2000); // pausa breve entre cuentas para no saturar X
  }

  await finishRun(null, {});
  return { listName: jobNameForResult(), text: `${totalTweets} tweets` };
}

async function finishRun(forcedMessage, opts) {
  if (!state.accumulated) {
    // No se encontró ningún tweet viable en ninguna cuenta: en vez de un archivo
    // vacío sin explicación, se deja una única línea neutra (no es "ruido" por
    // cuenta, es un resumen honesto de que no hubo nada que guardar).
    const text = 'No se encontraron tweets con contenido para este informe.';
    state.accumulated = state.format === 'rtf'
      ? `{\\pard\\fs20\\i ${rtfEscape(text)}\\par}\n`
      : text + '\n';
  }
  await saveFile();
  state.finished = true;
  const isLast = jobQueue.length === 0;
  const base = forcedMessage || `Terminado. Archivo guardado en Descargas: ${state.filename}`;
  const msg = state.jobTotal > 1
    ? `${base} (lista ${state.jobIndex} de ${state.jobTotal})`
    : base;
  setStatus(msg);
  if (isLast) {
    broadcast({ type: 'ALL_DONE', statusText: msg });
  } else {
    broadcast({ type: 'JOB_DONE', statusText: msg });
  }
}

// ============================================================================
// Construcción del informe: dos formatos, mismo contenido.
// - txt: igual que la versión original, texto plano.
// - rtf: se abre directamente en Word con negritas y tamaños de letra, sin
//   necesidad de librerías externas (no es un .docx real, que requiere generar
//   un ZIP con XML dentro; RTF es texto plano que Word interpreta igual de bien).
// ============================================================================
function buildHeaderText(format, disp, accounts, jobLabel, isKeyword, keyword) {
  const title = `NOTICIAS DEL DÍA ${disp}`;
  const metaLines = [];
  // En modo palabra clave, jobLabel ya es exactamente 'Búsqueda: "..."', así que no
  // se repite aquí; en modo cuentas, jobLabel es opcional (p.ej. "Lista: Fútbol") y
  // se añade además la lista de cuentas.
  if (jobLabel) metaLines.push(jobLabel);
  if (!isKeyword) metaLines.push(`Cuentas: ${accounts.map((a) => '@' + a).join(', ')}`);
  metaLines.push(`Generado: ${new Date().toLocaleString('es-ES')}`);

  if (format === 'rtf') {
    let s = `{\\pard\\b\\fs32 ${rtfEscape(title)}\\par}\n`;
    for (const line of metaLines) s += `{\\pard\\fs20 ${rtfEscape(line)}\\par}\n`;
    s += '{\\pard\\par}\n';
    return s;
  }
  let s = title + '\n';
  for (const line of metaLines) s += line + '\n';
  return s;
}

// Bloque opcional al principio del informe con una plantilla de prompt lista para
// pegar en Claude (u otra IA): así también le sirve a quien no sepa nada de esto.
function buildAiPromptBlock(format) {
  const heading = 'Cómo sacarle partido con IA (opcional)';
  const body = 'Copia el texto de este informe (o solo las noticias que te interesen) y pégalo en Claude '
    + '(claude.ai) con un mensaje como: "Analiza estas noticias, busca más contexto sobre las más '
    + 'relevantes y escríbeme un guion corto para hablar de cada una." No hace falta saber nada '
    + 'técnico: basta con copiar y pegar.';
  if (format === 'rtf') {
    return `{\\pard\\b\\fs22 ${rtfEscape(heading)}\\par}\n{\\pard\\fs18\\i ${rtfEscape(body)}\\par}\n{\\pard\\par}\n`;
  }
  return `${heading}\n${body}\n\n`;
}

function buildSectionText(format, handle, disp, res, labelOverride) {
  return format === 'rtf'
    ? buildSectionRtf(handle, disp, res, labelOverride)
    : buildSectionTxt(handle, disp, res, labelOverride);
}

function buildSectionTxt(handle, disp, res, labelOverride) {
  let s = '\n========================================\n';
  s += `${labelOverride || '@' + handle} — ${disp}\n`;
  s += '========================================\n';

  if (res.error === 'notfound') { s += 'Cuenta no encontrada, suspendida o sin tweets visibles.\n'; return s + '\n'; }
  if (res.error === 'timeout') { s += 'No se pudo completar la revisión (tiempo agotado).\n'; return s + '\n'; }
  if (res.error === 'login') { s += (res.errorNote || 'No se pudo acceder.') + '\n'; return s + '\n'; }
  if (res.error) { s += 'No se pudo extraer información de esta cuenta.\n'; return s + '\n'; }
  if (!res.tweets || res.tweets.length === 0) { s += `— Sin tweets encontrados con fecha ${disp} —\n`; return s + '\n'; }

  s += `(${res.tweets.length} tweets)\n\n`;
  for (const t of res.tweets) {
    let line = `[${t.time}]`;
    if (t.repost) line += ' [Repost]';
    line += ' ' + (t.text ? t.text.replace(/\s*\n\s*/g, ' / ') : '(sin texto)');
    if (t.media) line += ' ' + t.media;
    s += line + '\n';
    if (t.quote) s += `    ↳ Cita: ${t.quote.replace(/\s*\n\s*/g, ' / ')}\n`;
    if (t.url) s += `    ${t.url}\n`;
    s += '\n';
  }
  return s + '\n';
}

function rtfEscape(str) {
  if (!str) return '';
  let out = '';
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    const code = str.charCodeAt(i);
    if (ch === '\\') out += '\\\\';
    else if (ch === '{') out += '\\{';
    else if (ch === '}') out += '\\}';
    else if (ch === '\n' || ch === '\r') out += '\\line ';
    else if (code > 126) {
      const signed = code > 32767 ? code - 65536 : code; // RTF usa enteros de 16 bits con signo
      out += `\\u${signed}?`;
    } else {
      out += ch;
    }
  }
  return out;
}

function buildSectionRtf(handle, disp, res, labelOverride) {
  const label = labelOverride || `@${handle}`;
  let s = `{\\pard\\keepn\\b\\fs26 ${rtfEscape(label)} \\u8212? ${rtfEscape(disp)}\\par}\n`;
  const noteLine = (text) => `{\\pard\\fs20\\i ${rtfEscape(text)}\\par}\n{\\pard\\par}\n`;

  if (res.error === 'notfound') return s + noteLine('Cuenta no encontrada, suspendida o sin tweets visibles.');
  if (res.error === 'timeout') return s + noteLine('No se pudo completar la revisión (tiempo agotado).');
  if (res.error === 'login') return s + noteLine(res.errorNote || 'No se pudo acceder.');
  if (res.error) return s + noteLine('No se pudo extraer información de esta cuenta.');
  if (!res.tweets || res.tweets.length === 0) return s + noteLine(`— Sin tweets encontrados con fecha ${disp} —`);

  s += `{\\pard\\fs18\\i (${res.tweets.length} tweets)\\par}\n{\\pard\\par}\n`;
  for (const t of res.tweets) {
    let line = `{\\pard\\fs20 {\\b [${rtfEscape(t.time)}]}`;
    if (t.repost) line += ' {\\b [Repost]}';
    line += ' ' + rtfEscape(t.text ? t.text.replace(/\s*\n\s*/g, ' / ') : '(sin texto)');
    if (t.media) line += ' ' + rtfEscape(t.media);
    line += '\\par}\n';
    s += line;
    if (t.quote) s += `{\\pard\\li360\\fs20\\i \\u8627? Cita: ${rtfEscape(t.quote.replace(/\s*\n\s*/g, ' / '))}\\par}\n`;
    if (t.url) s += `{\\pard\\li360\\fs18\\cf0 ${rtfEscape(t.url)}\\par}\n`;
    s += '{\\pard\\par}\n';
  }
  return s;
}

// Índice de titulares al principio del informe: una línea por tweet válido
// (hora, cuenta, primeras palabras) para decidir rápido qué desarrollar sin
// tener que leer el documento entero. Se reconstruye en cada guardado a partir
// de state.headlineItems, así que un informe a medias también lleva su índice.
function buildHeadlineIndex(format, items) {
  if (!items || items.length === 0) return '';
  const heading = 'Titulares (para elegir rápido qué desarrollar)';
  const snippetOf = (text) => {
    const clean = (text || '(sin texto)').replace(/\s*\n\s*/g, ' / ');
    return clean.length > 110 ? clean.slice(0, 110) + '…' : clean;
  };
  if (format === 'rtf') {
    let s = `{\\pard\\b\\fs24 ${rtfEscape(heading)}\\par}\n`;
    items.forEach((it) => {
      const tag = it.repost ? ' [Repost]' : '';
      s += `{\\pard\\fs19 \\bullet  {\\b [${rtfEscape(it.time)}] ${rtfEscape(it.handle)}${tag}} \\u8212? ${rtfEscape(snippetOf(it.text))}\\par}\n`;
    });
    s += '{\\pard\\par}\n';
    return s;
  }
  let s = heading + '\n';
  items.forEach((it) => {
    const tag = it.repost ? ' [Repost]' : '';
    s += `- [${it.time}] ${it.handle}${tag} — ${snippetOf(it.text)}\n`;
  });
  return s + '\n';
}

function saveFile() {
  const RTF_PREAMBLE = '{\\rtf1\\ansi\\ansicpg1252\\deff0{\\fonttbl{\\f0\\fswiss Calibri;}}\\viewkind4\\uc1\\pard\\f0\\fs22\n';
  const index = buildHeadlineIndex(state.format, state.headlineItems);
  let content, mime;
  if (state.format === 'rtf') {
    content = RTF_PREAMBLE + state.headerText + index + state.accumulated + '}';
    mime = 'application/rtf';
  } else {
    content = state.headerText + index + state.accumulated;
    mime = 'text/plain;charset=utf-8';
  }
  const url = `data:${mime},` + encodeURIComponent(content);
  return new Promise((resolve) => {
    chrome.downloads.download(
      { url, filename: state.filename, conflictAction: 'overwrite', saveAs: false },
      () => resolve()
    );
  });
}

// Busca una ventana normal de Chrome donde abrir las pestañas de X; si no hay
// ninguna (por ejemplo, el usuario solo tiene abierta la ventana de control),
// crea una nueva en segundo plano. Así las pestañas nunca se abren dentro de la
// propia ventana de control (que no tiene barra de pestañas) ni le quitan el foco.
async function getHostWindowId() {
  const windows = await chrome.windows.getAll({ windowTypes: ['normal'] });
  if (windows.length > 0) return windows[0].id;
  const win = await chrome.windows.create({ url: 'about:blank', focused: false });
  return win.id;
}

// ============================================================================
// Apertura de la pestaña de X y extracción. Las pestañas se abren en segundo
// plano (active: false) para no robarle el foco a la ventana de control: así
// puedes dejarla abierta y pulsar Pausar/Detener en cualquier momento.
// ============================================================================
// X interpreta "until:FECHA" como "antes de esa fecha" (no incluye el propio día),
// así que para incluir el último día del rango en una búsqueda hay que pedir
// "hasta el día siguiente".
function addOneDay(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  d.setDate(d.getDate() + 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function buildTargetUrl(handle, dateFrom, dateTo, mode, keyword) {
  if (mode === 'keyword') {
    const query = `${keyword} since:${dateFrom} until:${addOneDay(dateTo)}`;
    return `https://x.com/search?q=${encodeURIComponent(query)}&src=typed_query&f=live`;
  }
  return `https://x.com/${handle}`;
}

async function processAccount(handle, dateFrom, dateTo, includeReposts, mode, keyword) {
  const hostWindowId = await getHostWindowId();
  const url = buildTargetUrl(handle, dateFrom, dateTo, mode, keyword);
  return new Promise((resolve) => {
    let finished = false;
    let tabId = null;
    let activeMs = 0;
    const numDays = Math.round((new Date(dateTo) - new Date(dateFrom)) / 86400000) + 1;
    // Más días de rango => más tiempo permitido antes de considerar que se ha colgado (tope 10 min).
    const LIMIT_MS = Math.min(100000 * Math.max(numDays, 1), 600000);

    function finish(result) {
      if (finished) return;
      finished = true;
      clearInterval(safetyTick);
      if (tabId != null) chrome.tabs.remove(tabId).catch(() => {});
      resolve(result);
    }

    // Se comprueba cada segundo; si está en pausa, no se acumula tiempo, así que
    // pausar para resolver un captcha, por ejemplo, no dispara el timeout.
    const safetyTick = setInterval(async () => {
      if (finished) return;
      const c = await getControl();
      if (c.stop) { finish({ tweets: [], stoppedByUser: true }); return; }
      if (!c.pause) activeMs += 1000;
      if (activeMs >= LIMIT_MS) finish({ error: 'timeout', errorNote: 'tiempo agotado' });
    }, 1000);

    chrome.tabs.create({ url, active: false, windowId: hostWindowId }, (tab) => {
      if (finished) { chrome.tabs.remove(tab.id).catch(() => {}); return; }
      tabId = tab.id;

      const listener = (updatedTabId, changeInfo) => {
        if (updatedTabId === tabId && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          setTimeout(() => {
            if (finished) return;
            chrome.scripting.executeScript(
              { target: { tabId }, func: collectTweetsForDate, args: [dateFrom, dateTo, includeReposts] },
              (results) => {
                if (chrome.runtime.lastError || !results || !results[0] || !results[0].result) {
                  finish({ error: 'inject', errorNote: 'no se pudo analizar' });
                } else {
                  finish(results[0].result);
                }
              }
            );
          }, 3000); // espera a que X pinte el feed
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  });
}

// ============================================================================
// Diagnóstico: abre una cuenta de prueba en segundo plano y comprueba que los
// selectores que usa la extracción (tweet, fecha, texto) siguen encontrando
// cosas en la X actual. Sirve para distinguir "X cambió su web" de otros
// problemas (sesión no iniciada, sin internet, etc.).
// ============================================================================
async function runDiagnostic(handle) {
  const target = (handle || 'X').replace(/^@/, '');
  const hostWindowId = await getHostWindowId();
  return new Promise((resolve) => {
    let finished = false;
    let tabId = null;

    function finish(result) {
      if (finished) return;
      finished = true;
      clearTimeout(safety);
      if (tabId != null) chrome.tabs.remove(tabId).catch(() => {});
      resolve(result);
    }

    const safety = setTimeout(() => finish({ ok: false, note: 'Tiempo agotado comprobando la cuenta de prueba.' }), 20000);

    chrome.tabs.create({ url: `https://x.com/${target}`, active: false, windowId: hostWindowId }, (tab) => {
      if (finished) { chrome.tabs.remove(tab.id).catch(() => {}); return; }
      tabId = tab.id;
      const listener = (updatedTabId, changeInfo) => {
        if (updatedTabId === tabId && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          setTimeout(() => {
            if (finished) return;
            chrome.scripting.executeScript(
              { target: { tabId }, func: diagnosticCheck },
              (results) => {
                if (chrome.runtime.lastError || !results || !results[0]) {
                  finish({ ok: false, note: 'No se pudo analizar la pestaña de prueba.' });
                } else {
                  finish(results[0].result);
                }
              }
            );
          }, 3000);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  });
}

// ---- Se ejecuta DENTRO de la página de X, solo para el diagnóstico ----
async function diagnosticCheck() {
  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
  let waited = 0;
  while (waited < 10000) {
    if (document.querySelector('article[data-testid="tweet"]')) break;
    if (location.pathname.includes('/i/flow/login')) return { ok: false, note: 'No hay sesión iniciada en X en este navegador.' };
    await sleep(500);
    waited += 500;
  }
  const art = document.querySelector('article[data-testid="tweet"]');
  if (!art) return { ok: false, note: 'No se encontraron tweets en la cuenta de prueba: puede que X haya cambiado su web, o que esa cuenta no tenga tweets recientes.' };
  const hasTime = !!art.querySelector('time[datetime]');
  const hasText = !!art.querySelector('[data-testid="tweetText"]');
  if (!hasTime) return { ok: false, note: 'Los tweets no traen fecha detectable: parece que X ha cambiado su estructura interna. Puede que la extensión necesite una actualización.' };
  if (!hasText) return { ok: true, note: 'Lee fechas correctamente, aunque algún tweet no trae texto detectable (puede ser normal en tweets solo con imagen).' };
  return { ok: true, note: 'Todo en orden: la extensión sigue leyendo tweets, fechas y texto con normalidad.' };
}

// ---- Se ejecuta DENTRO de la página de X ----
// targetDateFrom / targetDateTo: 'YYYY-MM-DD'. Si son iguales, se comporta como un solo día.
async function collectTweetsForDate(targetDateFrom, targetDateTo, includeReposts) {
  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

  // El popup/background escriben aquí cuando el usuario pulsa Pausar/Detener.
  // Este script corre dentro de la pestaña, en un contexto aparte, así que consulta
  // chrome.storage.local directamente en lugar de compartir funciones con background.js.
  function getControl() {
    return new Promise((resolve) => {
      chrome.storage.local.get('xnews_control', (data) => resolve(data.xnews_control || { stop: false, pause: false }));
    });
  }

  function localDateOf(iso) {
    const d = new Date(iso);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  // Esperar hasta 12 s a que aparezcan tweets, el aviso de cuenta vacía o el muro de login
  let waited = 0;
  while (waited < 12000) {
    if (document.querySelector('article[data-testid="tweet"]')) break;
    if (document.querySelector('[data-testid="empty_state_header_text"]')) break;
    if (location.pathname.includes('/i/flow/login')) break;
    if ((await getControl()).stop) return { tweets: [], stoppedByUser: true };
    await sleep(500);
    waited += 500;
  }

  if (
    location.pathname.includes('/i/flow/login') ||
    document.querySelector('a[data-testid="loginButton"]') ||
    document.querySelector('[data-testid="login"]')
  ) {
    return { error: 'login' };
  }

  if (
    !document.querySelector('article[data-testid="tweet"]') &&
    document.querySelector('[data-testid="empty_state_header_text"]')
  ) {
    return { error: 'notfound' };
  }
  if (!document.querySelector('article[data-testid="tweet"]')) {
    return { error: 'notfound' };
  }

  const collected = new Map();
  const numDays = Math.round((new Date(targetDateTo) - new Date(targetDateFrom)) / 86400000) + 1;
  const maxScrolls = Math.min(40 * Math.max(numDays, 1), 250); // rangos más amplios necesitan más scroll
  let olderPasses = 0;
  let stagnantPasses = 0;
  let prevCount = 0;
  let prevHeight = 0;
  let stoppedByUser = false;

  for (let i = 0; i < maxScrolls; i++) {
    // Comprobar pausa/detención antes de cada pasada de scroll
    let ctrl = await getControl();
    if (ctrl.stop) { stoppedByUser = true; break; }
    while (ctrl.pause && !ctrl.stop) {
      await sleep(400);
      ctrl = await getControl();
    }
    if (ctrl.stop) { stoppedByUser = true; break; }

    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    let olderNonContext = 0;

    for (const art of articles) {
      const timeEl = art.querySelector('time');
      if (!timeEl) continue;
      const iso = timeEl.getAttribute('datetime');
      if (!iso) continue;

      const linkEl = timeEl.closest('a');
      const url = linkEl ? linkEl.href : null;
      const key = url || iso + (art.textContent || '').slice(0, 60);

      const ctxEl = art.querySelector('[data-testid="socialContext"]');
      const hasContext = !!ctxEl; // repost o tweet fijado
      const isPinned = hasContext && /fijado|pinned|fijada/i.test(ctxEl.textContent || '');
      const isRepost = hasContext && !isPinned;

      const tweetDay = localDateOf(iso);

      if (tweetDay >= targetDateFrom && tweetDay <= targetDateTo) {
        // Si el usuario no quiere reposts, se ignoran del todo aquí (ni se cuentan
        // ni se guardan), tanto si son de la fecha buscada como si no.
        if (isRepost && includeReposts === false) {
          // no hacer nada
        } else if (!collected.has(key)) {
          const textEls = art.querySelectorAll('[data-testid="tweetText"]');
          const text = textEls[0] ? textEls[0].innerText : '';
          const quote = textEls[1] ? textEls[1].innerText : '';

          let media = '';
          if (art.querySelector('[data-testid="videoPlayer"], video')) media = '[incluye vídeo]';
          else if (art.querySelector('[data-testid="tweetPhoto"]')) media = '[incluye imagen]';

          const d = new Date(iso);
          const time = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

          collected.set(key, { iso, time, text, quote, media, url, repost: isRepost });
        }
      } else if (tweetDay < targetDateFrom && !hasContext) {
        // tweet propio más antiguo que la fecha objetivo (ignoramos fijados/reposts para no cortar antes de tiempo)
        olderNonContext++;
      }
    }

    // Condición de parada 1: llevamos dos pasadas seguidas viendo varios tweets ya más antiguos
    if (olderNonContext >= 3) olderPasses++;
    else olderPasses = 0;
    if (olderPasses >= 2) break;

    // Condición de parada 2: la página ya no crece ni aparecen tweets nuevos (fin del feed)
    const height = document.body.scrollHeight;
    if (collected.size === prevCount && height === prevHeight) stagnantPasses++;
    else stagnantPasses = 0;
    if (stagnantPasses >= 4) break;
    prevCount = collected.size;
    prevHeight = height;

    window.scrollBy(0, window.innerHeight * 2);
    await sleep(1200);
  }

  const tweets = Array.from(collected.values()).sort((a, b) => b.iso.localeCompare(a.iso));
  return { tweets, stoppedByUser };
}
