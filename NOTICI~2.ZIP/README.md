# Noticias del Día en X (Twitter) — Extensión de Chrome

Le das una o varias cuentas de X, eliges una fecha (o un rango de fechas), y la
extensión visita cada cuenta por orden, baja por su feed, extrae los tweets de esas
fechas y los guarda en un archivo **Word (.rtf)** o de texto en tu carpeta de
Descargas, con un **índice de titulares** al principio para ver de un vistazo qué
hay. Puedes guardar grupos de cuentas como **listas favoritas** y **programarlas**
para que se busquen solas a una hora fija (una lista = un archivo).

## Requisitos imprescindibles (léelo aunque parezca obvio)

1. **Sesión iniciada en x.com en el navegador Google Chrome.** X ya no muestra los
   perfiles a visitantes sin cuenta. Si no hay sesión, la extensión lo detecta, te lo
   dice y se detiene (no se queda colgada).
2. **Para que una programación se ejecute sola**, Google Chrome tiene que estar
   **abierto** en el ordenador a esa hora — no hace falta que lo estés mirando ni
   tener ninguna ventana de la extensión abierta, basta con que Chrome esté
   funcionando en segundo plano. Si Chrome estaba cerrado, la búsqueda pendiente se
   hace en cuanto lo vuelvas a abrir. No hace falta tener Claude, ninguna cuenta de
   Google, ni nada más: solo Chrome abierto y tu sesión de X activa en él.

## Instalación

1. Descomprime este ZIP.
2. Chrome → `chrome://extensions` → activa **"Modo de desarrollador"**.
3. **"Cargar descomprimida"** → selecciona la carpeta descomprimida.

## La ventana de control

Al hacer clic en el icono de la extensión se abre una **ventana propia**, no un
desplegable que se cierra solo: puedes dejarla abierta todo el tiempo que quieras
(aunque cambies de pestaña o la extensión abra pestañas de X en segundo plano) y
pulsar Pausar/Detener cuando te haga falta. Si ya la tenías abierta, un nuevo clic
en el icono la trae al frente en vez de abrir otra.

Dentro tiene 4 pestañas: **Extraer** (uso manual), **Listas**, **Programaciones** y
**Preferencias** — todo en el mismo sitio, nada se abre en una pestaña aparte del
navegador. La primera vez que la abres (y cada vez que quieras, con el botón **?**)
verás una pantalla de bienvenida con lo esencial; puedes marcar "no volver a
mostrar" si ya te lo sabes.

## Uso rápido (pestaña "Extraer", sin listas ni programación)

1. Pega las cuentas separadas por comas (con o sin @, incluso URLs de perfil valen):
   `@FabrizioRomano, @David_Ornstein, @MatteMoretto, @infobae`
2. Elige las fechas "Desde" y "Hasta" (ambas salen puestas en HOY; déjalas iguales
   para un solo día, o pon un rango para buscar en varios días de golpe).
3. Pulsa **"Extraer noticias"**.
4. La extensión abrirá cada perfil por turnos **en segundo plano** (sin robarte el
   foco ni tapar la ventana de control), hará scroll por su feed recogiendo los
   tweets de esas fechas, y **tras cada cuenta actualizará el archivo** en Descargas.
   Si algo se interrumpe a mitad, conservas en el archivo todo lo extraído hasta
   ese momento.
5. Verás el progreso cuenta a cuenta y cuántos tweets se sacaron de cada una.
6. Mientras trabaja, tienes dos botones:
   - **⏸ Pausar / ▶ Reanudar**: congela el scroll donde esté (útil si X pide verificación
     o un captcha y necesitas intervenir a mano). El archivo no se toca mientras está pausado.
   - **⏹ Detener**: para la extracción en cuanto termina la pasada de scroll actual (normalmente
     en 1-2 segundos), descarta las cuentas o listas que quedaban por revisar y guarda
     igualmente el archivo con todo lo recogido hasta ese momento.

## Buscar por palabra clave (en vez de por cuentas)

En la pestaña "Extraer" puedes elegir cómo buscar: **por cuentas** (lo de siempre) o
**por palabra clave** — nunca las dos a la vez. En el segundo modo, la extensión no
visita perfiles: usa el propio buscador de X con tu palabra o frase y el rango de
fechas elegido, y recoge lo que encuentre en toda X. Útil para rastrear un tema
("fichaje oficial", el nombre de un jugador, etc.) sin tener que saber de antemano
qué cuentas van a hablar de ello.

## Diagnóstico: comprobar que sigue funcionando

X cambia su web de vez en cuando, y eso puede romper la lectura de tweets sin previo
aviso. En la pestaña Preferencias hay un botón **"🩺 Comprobar que sigue
funcionando"**: abre una cuenta de prueba en segundo plano y te dice con claridad si
todo va bien o si parece que X ha cambiado algo (para saber si hace falta esperar una
actualización en vez de pensar que algo se ha roto para siempre).

## Listas favoritas y programaciones

- **Listas favoritas** (pestaña Listas): crea grupos de cuentas con nombre (ej.
  "Fútbol", "Política"). Se pueden usar desde "Extraer" con el desplegable "Cargar
  una lista guardada", o ejecutar al momento con el botón **"Ejecutar ahora"** de
  cada lista.
- **Programaciones** (pestaña Programaciones): elige una hora, qué días de la
  semana y qué listas se deben buscar automáticamente. A esa hora, la extensión
  abrirá sola cada cuenta de cada lista seleccionada y guardará **un archivo por
  lista**, con la fecha de ese día. Recibirás una notificación de escritorio cuando
  termine. Recuerda los dos requisitos de arriba: Chrome abierto y sesión en X.
- **Preferencias**: formato de archivo (Word .rtf recomendado, o texto plano),
  incluir o no la plantilla de IA al principio, e incluir o no los reposts.

## El índice de titulares (para elegir qué desarrollar, sin gastar IA)

Cada archivo empieza con una lista compacta de una línea por tweet encontrado
(hora, cuenta y primeras palabras), antes del contenido completo. Así abres el
documento, en unos segundos ves de qué van todas las noticias, y eliges cuál
desarrollar — sin necesidad de leerlo entero ni de usar ninguna IA para "resumir".

Si además quieres pedirle a una IA que investigue una noticia a fondo y te escriba
un guion, cada archivo incluye (si lo dejas activado en Preferencias) una plantilla
lista para copiar y pegar en Claude (claude.ai, gratis para empezar): eliges la
noticia en el índice, copias esa parte del documento y se la pegas a Claude con el
mensaje sugerido. No hace falta clave de API ni nada técnico.

## Formato del archivo (ejemplo en texto; en Word se ve igual pero con negritas)

```
NOTICIAS DEL DÍA 27/07/2026
Lista: Fútbol
Cuentas: @FabrizioRomano, @infobae
Generado: 27/7/2026, 9:15

Cómo sacarle partido con IA (opcional)
Copia el texto de este informe... [plantilla de prompt]

Titulares (para elegir rápido qué desarrollar)
• [08:45] @FabrizioRomano — Official, confirmed. Player X joins Club Y...
• [07:30] @FabrizioRomano [Repost] — Understand talks are ongoing...

========================================
@FabrizioRomano — 27/07/2026
========================================
(2 tweets)

[08:45] Official, confirmed. Player X joins Club Y. Here we go! [incluye imagen]
    https://x.com/FabrizioRomano/status/...

[07:30] [Repost] Understand talks are ongoing between clubs tonight.
    ↳ Cita: Exclusive: negotiations advancing
    https://x.com/FabrizioRomano/status/...
```

Cada tweet incluye: hora local, marca de [Repost] si es un retweet, el texto, la nota
de si incluye imagen o vídeo, el texto citado si es un tweet con cita, y el enlace
directo al tweet. Los tweets van ordenados del más reciente al más antiguo. **Solo
se guardan tweets con contenido real**: las cuentas sin tweets, no encontradas o con
error no escriben nada en el archivo (esa información solo se ve en el progreso en
pantalla). Si un día no hay nada que guardar, el archivo lleva una única línea
explicándolo en vez de quedar vacío sin más.

## Nombres de archivo

- Extracción manual sin lista: `NoticiasHoy27072026.rtf` (o `.txt`).
- Extracción manual con rango de fechas: `NoticiasHoy27072026-30072026.rtf`.
- Lista o programación: `Noticias_NombreDeLaLista_27072026.rtf`.
- Búsqueda por palabra clave: `Busqueda_palabra_clave_27072026.rtf`.

## Detalles técnicos que conviene saber

- **"Añadir" al archivo**: las extensiones de Chrome no pueden escribir líneas
  dentro de un archivo ya guardado en disco. Para conseguir el mismo efecto, la
  extensión guarda en memoria todo el contenido acumulado y, tras cada cuenta, vuelve
  a guardar el archivo completo con el mismo nombre (sobrescribiendo la versión
  anterior, que siempre está contenida en la nueva). Verás varias entradas en la
  barra de descargas de Chrome (una por actualización); es normal, todas apuntan al
  mismo archivo.
- **El formato Word no es un .docx real**: generar un .docx de verdad requiere crear
  un ZIP con XML dentro, algo que no se puede hacer de forma fiable sin librerías
  externas pesadas. En su lugar se genera un **.rtf**, un formato de texto que Word
  abre de forma nativa, con negritas, tamaños de letra y tildes/emojis correctos,
  sin avisos raros al abrirlo.
- **Pestañas en segundo plano**: para no robarle el foco a la ventana de control,
  las cuentas se abren como pestañas inactivas en una ventana normal de Chrome (se
  crea una si no tienes ninguna abierta). Nunca se abren dentro de la propia ventana
  de control.
- **Cómo decide cuándo dejar de bajar**: el feed de un perfil va del tweet más
  reciente al más antiguo, así que cuando la extensión empieza a ver varios tweets
  propios (no fijados ni reposts) con fecha anterior al principio del rango elegido,
  deja de hacer scroll. Los tweets fijados antiguos no la confunden.
- **Reposts**: X muestra en los retweets la fecha del tweet original, no la del
  momento de retuitear, así que un repost de contenido antiguo debería quedar fuera
  al buscar solo "hoy". Si aun así no te interesan los reposts, puedes desactivarlos
  del todo en Preferencias ("Incluir reposts").
- **Límite de scroll**: hasta 40 pasadas de scroll por cuenta y día de rango (varios
  cientos de tweets), con un tope de 250 pasadas. En cuentas extremadamente activas,
  si el periodo elegido tiene más tweets que eso, se recogerán los más recientes.
- **Tiempos de seguridad**: hasta 100 segundos activos por cuenta y día de rango
  (tope 10 minutos). El tiempo en pausa no cuenta. Si una página no responde, se
  anota el fallo en el progreso (no en el archivo) y se continúa con la siguiente;
  la extensión nunca se queda colgada.
- **Programaciones y cola**: si una programación incluye varias listas, se procesan
  una detrás de otra (nunca a la vez) para no saturar X con muchas pestañas abiertas.
- **X cambia su web a menudo**: la extracción se basa en la estructura interna
  actual de x.com (atributos `data-testid`). Si X la cambia en el futuro, puede
  hacer falta actualizar la extensión.
- **Uso personal y con moderación**: esto automatiza la lectura de tu propia sesión
  de X. Úsalo con listas razonables de cuentas y no lo lances en bucle constante,
  tanto para no saturar X como porque un uso automatizado intensivo puede chocar
  con sus condiciones de uso o hacer que te pidan verificación/captcha.

## Para vender con tranquilidad: aviso de versión e interruptor de apagado

**Importante: por defecto esta función está apagada.** Sin configurarla, la
extensión funciona exactamente igual que antes, sin comprobar nada por internet.

Si quieres poder avisar de nuevas versiones y, si hiciera falta, desactivar todas
las copias vendidas a la vez, sigue estos pasos (dos minutos, sin programar nada):

1. Entra en [gist.github.com](https://gist.github.com/) con una cuenta de GitHub
   (gratis, si no tienes una créala en un minuto).
2. Crea un **Gist público nuevo**. Como nombre de archivo pon `xnews-config.json`, y
   pega este contenido:
   ```json
   {
     "latestVersion": "2.1",
     "downloadUrl": "https://tu-web-o-tienda.com/descarga",
     "changelog": "Primera versión con listas, programaciones y búsqueda por palabra clave.",
     "killSwitch": false,
     "killMessage": "Esta copia ha sido desactivada. Contacta con el vendedor para más información."
   }
   ```
3. Guarda el Gist ("Create public gist"). Pulsa el botón **"Raw"** del archivo y
   copia esa URL (empieza por `https://gist.githubusercontent.com/...`).
4. Abre `background.js`, busca la línea que empieza por `const REMOTE_CONFIG_URL`
   (cerca del principio del archivo) y pega ahí esa URL, entre las comillas.
5. Vuelve a cargar la extensión en `chrome://extensions` (botón de recargar).

A partir de ahí:

- Para **avisar de una versión nueva**, edita el Gist y sube el número de
  `latestVersion` (y opcionalmente `downloadUrl`/`changelog`). Todo el mundo que
  tenga la extensión instalada verá un aviso arriba, con enlace de descarga, la
  próxima vez que abran la ventana de control (se comprueba como mucho cada 30
  minutos, y nunca bloquea nada si no hay internet).
- Para **desactivar todas las copias**, cambia `killSwitch` a `true` y escribe el
  mensaje que quieras en `killMessage`. Deja de poder extraerse nada (ni a mano ni
  programado) hasta que lo vuelvas a poner en `false`. Es un interruptor global —
  afecta a todo el que tenga la extensión, no a una persona en concreto.

Este archivo también está referenciado en `PRIVACIDAD.md`: si lo activas, menciona
en tu política de privacidad (ya redactada, revísala) que existe esta comprobación.

## Prueba gratuita de 3 usos y suscripción

La extensión funciona entera y gratis durante **las primeras 3 búsquedas** (cada
pulsación de "Extraer noticias", cada ejecución manual de listas y cada búsqueda
programada cuenta como un uso). Pasado ese límite, se bloquea toda la extracción (a
mano y programada) hasta que se active un código de suscripción. El contador de usos
se guarda con `chrome.storage.sync`, que va ligada a la cuenta de Google con la que
cada persona tiene la sesión iniciada en Chrome — así, si alguien desinstala y
reinstala la extensión con la misma cuenta, el contador no vuelve a empezar de cero.
(Si esa persona no tiene sesión iniciada en Chrome, este aviso no se aplica y el
contador sí podría reiniciarse al reinstalar; no hay forma de evitar eso del todo,
como ya hablamos de que no existe una protección perfecta para una extensión.)

No pide ningún email ni inicio de sesión aparte del propio Chrome: todo el control
de usos es local, sin servidor propio, coherente con que nada se manda fuera del
ordenador de cada persona (ver `PRIVACIDAD.md`).

Todo esto se controla al principio de `background.js`, en el bloque que empieza por
`const TRIAL_USES`:

- `TRIAL_USES`: cuántas búsquedas gratis se permiten antes de pedir suscripción
  (por defecto, 3).
- `FRIEND_CODE`: un código fijo que tú decides (por defecto `COMPIS2026`) y que
  reparte acceso gratis e ilimitado a quien se lo des — cámbialo por el que
  quieras. Ten en cuenta que, como con cualquier código, si alguien a quien se lo
  diste se lo pasa a otra persona, esa persona también podrá usarlo: no hay forma
  de impedirlo del todo.
- `LICENSE_CHECKOUT_URL`: el enlace de pago al que se manda a quien pulsa
  "Suscribirme" en la pantalla de aviso (el que te dé Lemon Squeezy, Gumroad, etc.
  cuando crees tu producto — ver la sección de venta más abajo). Mientras esté
  vacío, ese botón avisa de que el pago aún no está listo, pero el código de
  amigos sigue funcionando igual.

Ahora mismo, la comprobación de un código de pago real (más allá del código de
amigos) es un hueco marcado con `TODO` dentro de la función `checkLicenseKey` en
`background.js`: cuando actives las ventas con Lemon Squeezy u otro servicio,
hay que añadir ahí la llamada a su sistema de validación de licencias.

## Archivos del proyecto

- `manifest.json`
- `shared.js` — utilidades compartidas (parseo de cuentas, ids, nombres de archivo)
- `popup.html` / `popup.css` / `popup.js` — ventana de control única, con pestañas
  internas: Extraer, Listas, Programaciones y Preferencias, más la bienvenida
- `options.js` — lógica de Listas/Programaciones/Preferencias (se carga dentro de
  popup.html; sigue existiendo como archivo aparte para mantener el código ordenado)
- `options.html` — ya no muestra una interfaz propia; solo redirige a la ventana de
  control (para que el clic derecho → "Opciones" del icono siga funcionando)
- `options.css` — ya no se usa (los estilos se fusionaron en popup.css); se deja
  el archivo vacío con una nota para no romper referencias antiguas
- `background.js` — ventana de control, cola de trabajos, `chrome.alarms`,
  extracción con scroll (por cuentas o por palabra clave), diagnóstico, config
  remota (versión/interruptor), generación de Word (.rtf) / texto, índice de titulares
- `PRIVACIDAD.md` — política de privacidad, pensada para compartir con compradores
- `icons/`
