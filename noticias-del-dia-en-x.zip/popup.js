const setupView = document.getElementById('setupView');
const progressView = document.getElementById('progressView');
const statusLine = document.getElementById('statusLine');
const jobLabelEl = document.getElementById('jobLabel');
const listEl = document.getElementById('list');
const resetBtn = document.getElementById('resetBtn');
const dateFromInput = document.getElementById('dateFromInput');
const dateToInput = document.getElementById('dateToInput');
const accountsEl = document.getElementById('accounts');
const listSelect = document.getElementById('listSelect');
const pauseBtn = document.getElementById('pauseBtn');
const stopBtn = document.getElementById('stopBtn');
const helpBtn = document.getElementById('helpBtn');
const welcomeOverlay = document.getElementById('welcomeOverlay');
const welcomeCloseBtn = document.getElementById('welcomeCloseBtn');
const welcomeCloseForeverBtn = document.getElementById('welcomeCloseForeverBtn');
const welcomeCloseX = document.getElementById('welcomeCloseX');
const modeAccounts = document.getElementById('modeAccounts');
const modeKeyword = document.getElementById('modeKeyword');
const accountsModeDiv = document.getElementById('accountsMode');
const keywordModeDiv = document.getElementById('keywordMode');
const keywordInput = document.getElementById('keywordInput');
const updateBanner = document.getElementById('updateBanner');
const updateBannerText = document.getElementById('updateBannerText');
const updateBannerLink = document.getElementById('updateBannerLink');
const killBanner = document.getElementById('killBanner');
const killBannerText = document.getElementById('killBannerText');
const startBtn = document.getElementById('startBtn');
const diagnosticBtn = document.getElementById('diagnosticBtn');
const diagnosticResult = document.getElementById('diagnosticResult');
const versionText = document.getElementById('versionText');
const trialBanner = document.getElementById('trialBanner');
const trialBannerText = document.getElementById('trialBannerText');
const paywallOverlay = document.getElementById('paywallOverlay');
const paywallSubscribeBtn = document.getElementById('paywallSubscribeBtn');
const licenseKeyInput = document.getElementById('licenseKeyInput');
const licenseActivateBtn = document.getElementById('licenseActivateBtn');
const licenseActivateResult = document.getElementById('licenseActivateResult');

let selectedListName = null; // se limpia en cuanto el usuario toca el textarea a mano

function setPauseLabel(paused) {
  pauseBtn.textContent = paused ? '▶ Reanudar' : '⏸ Pausar';
}
function showControls() {
  pauseBtn.classList.remove('hidden');
  stopBtn.classList.remove('hidden');
  stopBtn.disabled = false;
}
function hideControls() {
  pauseBtn.classList.add('hidden');
  stopBtn.classList.add('hidden');
}
function setJobLabel(text) {
  if (text) { jobLabelEl.textContent = text; jobLabelEl.classList.remove('hidden'); }
  else { jobLabelEl.classList.add('hidden'); }
}

// Fechas por defecto: HOY en ambos campos (un solo día)
(function setToday() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const today = `${y}-${m}-${day}`;
  dateFromInput.value = today;
  dateToInput.value = today;
})();

// ---------- pestañas ----------
document.querySelectorAll('.tabBtn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tabBtn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.tabPanel').forEach((p) => p.classList.add('hidden'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.remove('hidden');
  });
});

// ---------- modo de búsqueda: por cuentas o por palabra clave (excluyentes) ----------
function applySearchMode() {
  const isKeyword = modeKeyword.checked;
  accountsModeDiv.classList.toggle('hidden', isKeyword);
  keywordModeDiv.classList.toggle('hidden', !isKeyword);
}
modeAccounts.addEventListener('change', applySearchMode);
modeKeyword.addEventListener('change', applySearchMode);
applySearchMode();

// ---------- versión, aviso de actualización e interruptor remoto ----------
versionText.textContent = 'Versión ' + chrome.runtime.getManifest().version;
chrome.runtime.sendMessage({ type: 'CHECK_UPDATE' }, (res) => {
  if (!res || !res.ok) return;
  if (res.killed) {
    killBannerText.textContent = res.killMessage || 'Esta copia de la extensión ha sido desactivada por el vendedor.';
    killBanner.classList.remove('hidden');
    startBtn.disabled = true;
  } else if (res.hasUpdate) {
    updateBannerText.textContent = `Hay una versión nueva disponible (${res.latest}, tienes la ${res.current}).`;
    if (res.downloadUrl) { updateBannerLink.href = res.downloadUrl; } else { updateBannerLink.classList.add('hidden'); }
    updateBanner.classList.remove('hidden');
  }
});

// ---------- prueba gratuita / suscripción ----------
let lastCheckoutUrl = '';

function refreshLicenseUI() {
  chrome.runtime.sendMessage({ type: 'CHECK_LICENSE' }, (res) => {
    if (!res) return;
    lastCheckoutUrl = res.checkoutUrl || '';
    if (!res.ok) {
      paywallOverlay.classList.remove('hidden');
      trialBanner.classList.add('hidden');
      return;
    }
    paywallOverlay.classList.add('hidden');
    if (res.trialActive && !res.hasPaidLicense) {
      trialBannerText.textContent = res.daysLeft <= 1
        ? 'Prueba gratuita: hoy es tu último día.'
        : `Prueba gratuita: quedan ${res.daysLeft} días.`;
      trialBanner.classList.remove('hidden');
    } else {
      trialBanner.classList.add('hidden');
    }
  });
}
refreshLicenseUI();

paywallSubscribeBtn.addEventListener('click', () => {
  if (lastCheckoutUrl) {
    window.open(lastCheckoutUrl, '_blank');
  } else {
    alert('El enlace de pago todavía no está configurado. Contacta con quien te dio la extensión.');
  }
});

licenseActivateBtn.addEventListener('click', () => {
  const key = licenseKeyInput.value.trim();
  if (!key) { licenseActivateResult.textContent = 'Escribe un código primero.'; return; }
  licenseActivateBtn.disabled = true;
  licenseActivateResult.textContent = 'Comprobando…';
  chrome.runtime.sendMessage({ type: 'ACTIVATE_LICENSE', key }, (res) => {
    licenseActivateBtn.disabled = false;
    if (!res) { licenseActivateResult.textContent = 'No se pudo comprobar el código.'; return; }
    if (res.ok) {
      licenseActivateResult.textContent = '';
      refreshLicenseUI();
    } else {
      licenseActivateResult.textContent = res.note || 'Código no válido.';
    }
  });
});

// ---------- diagnóstico ----------
diagnosticBtn.addEventListener('click', () => {
  const hint = modeAccounts.checked
    ? parseAccounts(accountsEl.value)[0]
    : null;
  diagnosticBtn.disabled = true;
  diagnosticResult.textContent = 'Comprobando…';
  chrome.runtime.sendMessage({ type: 'RUN_DIAGNOSTIC', handle: hint }, (res) => {
    diagnosticBtn.disabled = false;
    if (!res) { diagnosticResult.textContent = 'No se pudo comprobar (¿está Chrome bien conectado?).'; return; }
    diagnosticResult.textContent = res.ok
      ? '✅ Todo en orden: la extensión sigue leyendo tweets con normalidad.'
      : `⚠️ ${res.note || 'No se pudo confirmar que todo funcione bien.'}`;
  });
});

// ---------- bienvenida ----------
function showWelcome() { welcomeOverlay.classList.remove('hidden'); }
function hideWelcome() { welcomeOverlay.classList.add('hidden'); }
helpBtn.addEventListener('click', showWelcome);
welcomeCloseBtn.addEventListener('click', hideWelcome);
welcomeCloseX.addEventListener('click', hideWelcome);
welcomeCloseForeverBtn.addEventListener('click', () => {
  chrome.storage.local.set({ xnews_hideWelcome: true });
  hideWelcome();
});
chrome.storage.local.get('xnews_hideWelcome', (data) => {
  if (!data.xnews_hideWelcome) showWelcome();
});

accountsEl.addEventListener('input', () => { selectedListName = null; listSelect.value = ''; });

function loadLists() {
  chrome.storage.local.get('xnews_lists', (data) => {
    const lists = data.xnews_lists || [];
    listSelect.innerHTML = '<option value="">— Escribir cuentas a mano —</option>';
    lists.forEach((l) => {
      const opt = document.createElement('option');
      opt.value = l.id;
      opt.textContent = `${l.name} (${l.accounts.length})`;
      listSelect.appendChild(opt);
    });
  });
}
loadLists();

// Si se crea/edita/borra una lista desde la pestaña "Listas" (misma ventana),
// el desplegable de aquí se actualiza solo, sin tener que cerrar y reabrir nada.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.xnews_lists) loadLists();
});

listSelect.addEventListener('change', () => {
  if (!listSelect.value) { selectedListName = null; return; }
  chrome.storage.local.get('xnews_lists', (data) => {
    const lists = data.xnews_lists || [];
    const list = lists.find((l) => l.id === listSelect.value);
    if (!list) return;
    accountsEl.value = list.accounts.map((a) => '@' + a).join(', ');
    selectedListName = list.name;
  });
});

startBtn.addEventListener('click', () => {
  let dateFrom = dateFromInput.value;
  let dateTo = dateToInput.value;
  if (!dateFrom || !dateTo) { alert('Elige las fechas.'); return; }
  if (dateTo < dateFrom) { [dateFrom, dateTo] = [dateTo, dateFrom]; }

  const isKeyword = modeKeyword.checked;
  let payload;
  if (isKeyword) {
    const keyword = keywordInput.value.trim();
    if (!keyword) { alert('Escribe una palabra o frase a buscar.'); return; }
    payload = { type: 'START', mode: 'keyword', keyword, dateFrom, dateTo };
  } else {
    const accounts = parseAccounts(accountsEl.value);
    if (accounts.length === 0) { alert('Escribe al menos una cuenta.'); return; }
    payload = { type: 'START', mode: 'accounts', accounts, dateFrom, dateTo, listName: selectedListName };
  }

  setupView.classList.add('hidden');
  progressView.classList.remove('hidden');
  renderList(isKeyword ? [keywordInput.value.trim()] : parseAccounts(accountsEl.value), isKeyword ? 'keyword' : 'accounts');
  statusLine.textContent = 'Iniciando…';
  setJobLabel(isKeyword ? '' : (selectedListName ? `Lista: ${selectedListName}` : ''));
  setPauseLabel(false);
  showControls();
  resetBtn.classList.add('hidden');

  chrome.runtime.sendMessage(payload, (res) => {
    if (res && res.licenseRequired) {
      progressView.classList.add('hidden');
      setupView.classList.remove('hidden');
      refreshLicenseUI();
    }
  });
});

resetBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'RESET' });
  progressView.classList.add('hidden');
  resetBtn.classList.add('hidden');
  setupView.classList.remove('hidden');
  loadLists();
});

pauseBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'PAUSE_TOGGLE' });
});

stopBtn.addEventListener('click', () => {
  if (confirm('¿Seguro que quieres detener la extracción? Se guardará lo obtenido hasta ahora y se cancelará el resto de listas pendientes.')) {
    stopBtn.disabled = true;
    chrome.runtime.sendMessage({ type: 'STOP' });
  }
});

function renderList(accounts, mode) {
  listEl.innerHTML = '';
  accounts.forEach((h, i) => {
    const label = mode === 'keyword' ? `🔍 "${h}"` : `@${h}`;
    const row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = `
      <span class="n">${i + 1}</span>
      <span class="h">${label}</span>
      <span class="badge pending" id="badge-${i}">pendiente</span>
    `;
    listEl.appendChild(row);
  });
}

function applyItem(index, item) {
  const badge = document.getElementById('badge-' + index);
  if (!badge) return;
  badge.className = 'badge ' + item.status;
  const doneText = item.count === 0 ? 'sin tweets' : item.count + ' tweets';
  const map = {
    pending: 'pendiente',
    working: 'revisando…',
    done: item.note ? `${doneText} (${item.note})` : doneText,
    failed: item.note || 'error',
    skipped: 'omitida'
  };
  badge.textContent = map[item.status] || item.status;
}

chrome.runtime.sendMessage({ type: 'GET_STATE' }, (state) => {
  if (state && state.active) {
    setupView.classList.add('hidden');
    progressView.classList.remove('hidden');
    renderList(state.accounts, state.mode);
    state.items.forEach((item, i) => applyItem(i, item));
    statusLine.textContent = state.statusText || '';
    setJobLabel(state.jobTotal > 1 ? `${state.jobLabel} (lista ${state.jobIndex} de ${state.jobTotal})` : state.jobLabel);
    setPauseLabel(!!state.paused);
    if (state.finished) {
      hideControls();
      resetBtn.classList.remove('hidden');
    } else {
      showControls();
    }
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'STATUS') {
    statusLine.textContent = msg.statusText;
  } else if (msg.type === 'ACCOUNT_UPDATE') {
    applyItem(msg.index, msg.item);
  } else if (msg.type === 'PAUSE_STATE') {
    setPauseLabel(msg.paused);
  } else if (msg.type === 'JOB_START') {
    // Un trabajo programado o encolado ha empezado (puede que el popup ya estuviera abierto)
    setupView.classList.add('hidden');
    progressView.classList.remove('hidden');
    renderList(msg.accounts, msg.mode);
    setJobLabel(msg.jobTotal > 1 ? `${msg.jobLabel} (lista ${msg.jobIndex} de ${msg.jobTotal})` : msg.jobLabel);
    showControls();
    resetBtn.classList.add('hidden');
  } else if (msg.type === 'JOB_DONE') {
    // Termina una lista de la cola pero quedan más: se actualiza el texto, el siguiente
    // JOB_START reiniciará la vista.
    statusLine.textContent = msg.statusText;
  } else if (msg.type === 'ALL_DONE') {
    statusLine.textContent = msg.statusText;
    hideControls();
    resetBtn.classList.remove('hidden');
    if (msg.licenseRequired) refreshLicenseUI();
  }
});
