// Utilidades compartidas entre popup.js, options.js y background.js.
// Se carga como script clásico (sin módulos) para máxima compatibilidad:
// - popup.html / options.html lo incluyen con <script src="shared.js"> antes de su propio script.
// - background.js lo carga con importScripts('shared.js').

const DOW_LABELS = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

// Admite cualquier separador habitual (comas, punto y coma, espacios o saltos de línea,
// mezclados incluso en la misma lista) y el "@" es opcional: si alguien se despista al
// escribir, la búsqueda debe funcionar igual.
function parseAccounts(raw) {
  const parts = (raw || '').split(/[\s,;]+/);
  const seen = new Set();
  const out = [];
  for (let p of parts) {
    p = p.trim();
    if (!p) continue;
    p = p.replace(/^https?:\/\/(www\.)?(x|twitter)\.com\//i, '');
    p = p.replace(/^@/, '');
    p = p.replace(/[\/?#].*$/, '');
    p = p.replace(/[^a-zA-Z0-9_]+$/, ''); // quita puntuación suelta al final (puntos, comas residuales...)
    if (p && !seen.has(p.toLowerCase())) {
      seen.add(p.toLowerCase());
      out.push(p);
    }
  }
  return out;
}

// Convierte el nombre de una lista en algo seguro para usar como nombre de archivo.
function sanitizeFileName(name) {
  const cleaned = (name || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // quita acentos
    .replace(/[^a-zA-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return cleaned || 'Lista';
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// true si "days" (array de 0=domingo..6=sábado) incluye el día de la fecha dada,
// o si days está vacío/ausente (se interpreta como "todos los días").
function scheduleMatchesDay(days, date) {
  if (!days || days.length === 0) return true;
  return days.includes(date.getDay());
}

// true si "remote" (ej. "2.10") es una versión más nueva que "current" (ej. "2.9").
// Compara número a número, no como texto, para que "2.10" > "2.9" correctamente.
function isNewerVersion(remote, current) {
  if (!remote || !current) return false;
  const a = String(remote).split('.').map((n) => parseInt(n, 10) || 0);
  const b = String(current).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x > y) return true;
    if (x < y) return false;
  }
  return false;
}

if (typeof module !== 'undefined') {
  module.exports = { parseAccounts, sanitizeFileName, generateId, scheduleMatchesDay, DOW_LABELS, isNewerVersion };
}
