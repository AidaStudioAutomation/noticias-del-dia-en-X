const listsBody = document.getElementById('listsBody');
const listsEmpty = document.getElementById('listsEmpty');
const listForm = document.getElementById('listForm');
const listFormTitle = document.getElementById('listFormTitle');
const listNameInput = document.getElementById('listName');
const listAccountsInput = document.getElementById('listAccounts');
const listSaveBtn = document.getElementById('listSaveBtn');
const listCancelBtn = document.getElementById('listCancelBtn');

const schedulesBody = document.getElementById('schedulesBody');
const schedulesEmpty = document.getElementById('schedulesEmpty');
const scheduleForm = document.getElementById('scheduleForm');
const scheduleFormTitle = document.getElementById('scheduleFormTitle');
const scheduleNameInput = document.getElementById('scheduleName');
const scheduleTimeInput = document.getElementById('scheduleTime');
const scheduleDaysEl = document.getElementById('scheduleDays');
const scheduleListsEl = document.getElementById('scheduleLists');
const scheduleListsEmpty = document.getElementById('scheduleListsEmpty');
const scheduleEnabledInput = document.getElementById('scheduleEnabled');
const scheduleSaveBtn = document.getElementById('scheduleSaveBtn');
const scheduleCancelBtn = document.getElementById('scheduleCancelBtn');

const fmtRtf = document.getElementById('fmtRtf');
const fmtTxt = document.getElementById('fmtTxt');
const includeAiPromptInput = document.getElementById('includeAiPrompt');
const includeRepostsInput = document.getElementById('includeReposts');

let lists = [];
let schedules = [];
let editingListId = null;
let editingScheduleId = null;

// ---------- almacenamiento ----------
function loadAll() {
  chrome.storage.local.get(['xnews_lists', 'xnews_schedules', 'xnews_settings'], (data) => {
    lists = data.xnews_lists || [];
    schedules = data.xnews_schedules || [];
    const settings = Object.assign({ outputFormat: 'rtf', includeAiPrompt: true, includeReposts: true }, data.xnews_settings || {});
    fmtRtf.checked = settings.outputFormat === 'rtf';
    fmtTxt.checked = settings.outputFormat === 'txt';
    includeAiPromptInput.checked = settings.includeAiPrompt !== false;
    includeRepostsInput.checked = settings.includeReposts !== false;
    renderLists();
    renderScheduleListChips([]);
    renderSchedules();
  });
}
function saveLists() { return new Promise((r) => chrome.storage.local.set({ xnews_lists: lists }, r)); }
function saveSchedules() { return new Promise((r) => chrome.storage.local.set({ xnews_schedules: schedules }, r)); }
function syncAlarms() { chrome.runtime.sendMessage({ type: 'SYNC_ALARMS' }); }

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ============================================================================
// Listas favoritas
// ============================================================================
function renderLists() {
  listsBody.innerHTML = '';
  listsEmpty.classList.toggle('hidden', lists.length > 0);
  lists.forEach((l) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(l.name)}</td>
      <td>${l.accounts.length} cuenta${l.accounts.length === 1 ? '' : 's'}<br><span style="color:#71767b">${escapeHtml(l.accounts.map((a) => '@' + a).join(', '))}</span></td>
      <td><div class="rowActions">
        <button type="button" data-action="run" class="primary">Ejecutar ahora</button>
        <button type="button" data-action="edit">Editar</button>
        <button type="button" data-action="delete" class="danger">Eliminar</button>
      </div></td>
    `;
    tr.querySelector('[data-action="run"]').addEventListener('click', () => runListNow(l.id));
    tr.querySelector('[data-action="edit"]').addEventListener('click', () => editList(l.id));
    tr.querySelector('[data-action="delete"]').addEventListener('click', () => deleteList(l.id));
    listsBody.appendChild(tr);
  });
}

function editList(id) {
  const l = lists.find((x) => x.id === id);
  if (!l) return;
  editingListId = id;
  listFormTitle.textContent = `Editando: ${l.name}`;
  listNameInput.value = l.name;
  listAccountsInput.value = l.accounts.map((a) => '@' + a).join(', ');
  listSaveBtn.textContent = 'Guardar cambios';
  listCancelBtn.classList.remove('hidden');
  listNameInput.focus();
  listNameInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
function cancelListEdit() {
  editingListId = null;
  listFormTitle.textContent = 'Nueva lista';
  listForm.reset();
  listSaveBtn.textContent = 'Guardar lista';
  listCancelBtn.classList.add('hidden');
}
listCancelBtn.addEventListener('click', cancelListEdit);

listForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = listNameInput.value.trim();
  const accounts = parseAccounts(listAccountsInput.value);
  if (!name) { alert('Ponle un nombre a la lista.'); return; }
  if (accounts.length === 0) { alert('Añade al menos una cuenta.'); return; }

  if (editingListId) {
    const l = lists.find((x) => x.id === editingListId);
    if (l) { l.name = name; l.accounts = accounts; }
  } else {
    lists.push({ id: generateId(), name, accounts });
  }
  await saveLists();
  cancelListEdit();
  renderLists();
  renderSchedules();
  // refresca los chips de listas del formulario de programación si no se está editando ninguna
  if (!editingScheduleId) renderScheduleListChips([]);
});

async function deleteList(id) {
  const l = lists.find((x) => x.id === id);
  if (!l) return;
  if (!confirm(`¿Eliminar la lista "${l.name}"? Las programaciones que la usen dejarán de incluirla.`)) return;
  lists = lists.filter((x) => x.id !== id);
  schedules.forEach((s) => { s.listIds = (s.listIds || []).filter((lid) => lid !== id); });
  await saveLists();
  await saveSchedules();
  syncAlarms();
  if (editingListId === id) cancelListEdit();
  renderLists();
  renderSchedules();
  if (!editingScheduleId) renderScheduleListChips([]);
}

function runListNow(id) {
  chrome.runtime.sendMessage({ type: 'RUN_LISTS_NOW', listIds: [id] }, (res) => {
    if (res && res.ok) alert('Extracción en marcha. Abre el icono de la extensión para ver el progreso.');
    else alert('No se pudo iniciar la extracción.');
  });
}

// ============================================================================
// Programaciones
// ============================================================================
function renderScheduleDayChips(selectedDays) {
  scheduleDaysEl.innerHTML = '';
  DOW_LABELS.forEach((label, idx) => {
    const chip = document.createElement('label');
    const checked = selectedDays.includes(idx);
    chip.className = 'chip' + (checked ? ' checked' : '');
    chip.innerHTML = `<input type="checkbox" value="${idx}" ${checked ? 'checked' : ''}> ${label}`;
    chip.querySelector('input').addEventListener('change', (e) => {
      chip.classList.toggle('checked', e.target.checked);
    });
    scheduleDaysEl.appendChild(chip);
  });
}

function renderScheduleListChips(selectedIds) {
  scheduleListsEl.innerHTML = '';
  scheduleListsEmpty.classList.toggle('hidden', lists.length > 0);
  lists.forEach((l) => {
    const chip = document.createElement('label');
    const checked = selectedIds.includes(l.id);
    chip.className = 'chip' + (checked ? ' checked' : '');
    chip.innerHTML = `<input type="checkbox" value="${l.id}" ${checked ? 'checked' : ''}> ${escapeHtml(l.name)}`;
    chip.querySelector('input').addEventListener('change', (e) => {
      chip.classList.toggle('checked', e.target.checked);
    });
    scheduleListsEl.appendChild(chip);
  });
}

function getCheckedValues(container) {
  return Array.from(container.querySelectorAll('input[type="checkbox"]:checked')).map((i) => i.value);
}

function renderSchedules() {
  schedulesBody.innerHTML = '';
  schedulesEmpty.classList.toggle('hidden', schedules.length > 0);
  schedules.forEach((s) => {
    const dayText = (!s.days || s.days.length === 0 || s.days.length === 7)
      ? 'Todos los días'
      : s.days.slice().sort().map((d) => DOW_LABELS[d]).join(', ');
    const listNames = (s.listIds || []).map((id) => {
      const l = lists.find((x) => x.id === id);
      return l ? l.name : '(eliminada)';
    }).join(', ') || '—';
    const lastRunText = s.lastRun
      ? `${new Date(s.lastRun).toLocaleString('es-ES')}${s.lastResult ? ' — ' + s.lastResult : ''}`
      : 'Nunca';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.time)}</td>
      <td>${escapeHtml(dayText)}</td>
      <td>${escapeHtml(listNames)}</td>
      <td><span class="badge ${s.enabled ? 'on' : 'off'}">${s.enabled ? 'Activa' : 'Pausada'}</span></td>
      <td style="font-size:11px;color:#9ca3af">${escapeHtml(lastRunText)}</td>
      <td><div class="rowActions">
        <button type="button" data-action="toggle">${s.enabled ? 'Pausar' : 'Activar'}</button>
        <button type="button" data-action="edit">Editar</button>
        <button type="button" data-action="delete" class="danger">Eliminar</button>
      </div></td>
    `;
    tr.querySelector('[data-action="toggle"]').addEventListener('click', () => toggleSchedule(s.id));
    tr.querySelector('[data-action="edit"]').addEventListener('click', () => editSchedule(s.id));
    tr.querySelector('[data-action="delete"]').addEventListener('click', () => deleteSchedule(s.id));
    schedulesBody.appendChild(tr);
  });
}

async function toggleSchedule(id) {
  const s = schedules.find((x) => x.id === id);
  if (!s) return;
  s.enabled = !s.enabled;
  await saveSchedules();
  syncAlarms();
  renderSchedules();
}

function editSchedule(id) {
  const s = schedules.find((x) => x.id === id);
  if (!s) return;
  editingScheduleId = id;
  scheduleFormTitle.textContent = `Editando: ${s.name}`;
  scheduleNameInput.value = s.name;
  scheduleTimeInput.value = s.time;
  renderScheduleDayChips(s.days || []);
  renderScheduleListChips(s.listIds || []);
  scheduleEnabledInput.checked = !!s.enabled;
  scheduleSaveBtn.textContent = 'Guardar cambios';
  scheduleCancelBtn.classList.remove('hidden');
  scheduleNameInput.focus();
  scheduleNameInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function cancelScheduleEdit() {
  editingScheduleId = null;
  scheduleFormTitle.textContent = 'Nueva programación';
  scheduleNameInput.value = '';
  scheduleTimeInput.value = '09:00';
  renderScheduleDayChips([]);
  renderScheduleListChips([]);
  scheduleEnabledInput.checked = true;
  scheduleSaveBtn.textContent = 'Guardar programación';
  scheduleCancelBtn.classList.add('hidden');
}
scheduleCancelBtn.addEventListener('click', cancelScheduleEdit);

scheduleForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = scheduleNameInput.value.trim();
  const time = scheduleTimeInput.value;
  const days = getCheckedValues(scheduleDaysEl).map(Number);
  const listIds = getCheckedValues(scheduleListsEl);
  const enabled = scheduleEnabledInput.checked;

  if (!name) { alert('Ponle un nombre a la programación.'); return; }
  if (!time) { alert('Elige una hora.'); return; }
  if (listIds.length === 0) { alert('Elige al menos una lista.'); return; }

  if (editingScheduleId) {
    const s = schedules.find((x) => x.id === editingScheduleId);
    if (s) Object.assign(s, { name, time, days, listIds, enabled });
  } else {
    schedules.push({ id: generateId(), name, time, days, listIds, enabled, lastRun: null, lastResult: null });
  }
  await saveSchedules();
  syncAlarms();
  cancelScheduleEdit();
  renderSchedules();
});

async function deleteSchedule(id) {
  const s = schedules.find((x) => x.id === id);
  if (!s) return;
  if (!confirm(`¿Eliminar la programación "${s.name}"?`)) return;
  schedules = schedules.filter((x) => x.id !== id);
  await saveSchedules();
  syncAlarms();
  if (editingScheduleId === id) cancelScheduleEdit();
  renderSchedules();
}

// ============================================================================
// Preferencias
// ============================================================================
function saveSettings() {
  chrome.storage.local.set({
    xnews_settings: {
      outputFormat: fmtRtf.checked ? 'rtf' : 'txt',
      includeAiPrompt: includeAiPromptInput.checked,
      includeReposts: includeRepostsInput.checked
    }
  });
}
[fmtRtf, fmtTxt, includeAiPromptInput, includeRepostsInput].forEach((el) => {
  el.addEventListener('change', saveSettings);
});

// ============================================================================
renderScheduleDayChips([]);
loadAll();
