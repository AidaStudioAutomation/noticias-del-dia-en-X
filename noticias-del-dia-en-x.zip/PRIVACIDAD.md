# Política de privacidad — Noticias del Día en X (Twitter)

Última actualización: julio de 2026.

## Resumen en una frase

Esta extensión funciona **dentro de tu propio Chrome**, con **tu propia sesión** de X
(Twitter), y no manda tus datos a ningún sitio. Todo lo que extrae se queda en tu
ordenador, en los archivos que tú eliges guardar.

## Qué hace exactamente

- Abre, dentro de tu navegador, los perfiles de X (o el buscador de X) que tú le
  indiques, usando la sesión que ya tienes iniciada — como si lo hicieras tú a mano,
  pero automático.
- Lee el contenido de esos tweets (fecha, texto, si tiene imagen o vídeo, enlace) y
  lo guarda en un archivo de Word o de texto **en tu carpeta de Descargas**.
- Guarda tus listas de cuentas, tus programaciones y tus preferencias **solo en tu
  ordenador** (en el almacenamiento local de la extensión), nunca en un servidor.

## Qué NO hace

- No manda tus tweets, tus cuentas, tus listas ni ningún archivo generado a ningún
  servidor externo. Nada de lo que lees o guardas sale de tu ordenador.
- No accede a tus mensajes privados, ni a tu contraseña, ni a datos de tu cuenta más
  allá de lo que aparece públicamente en los tweets que visitas.
- No publica, ni da "me gusta", ni sigue cuentas, ni escribe nada en tu nombre. Solo
  lee.
- No usa cookies de seguimiento propias ni analítica de uso: no sabemos qué cuentas
  buscas, cuántas veces abres la extensión, ni nada parecido.

## La única conexión externa: comprobar la versión

La extensión consulta, de vez en cuando, un archivo público (controlado por quien te
vendió la extensión) para saber si hay una versión más reciente disponible. Esa
comprobación no envía ninguna información tuya: es una simple petición para leer un
archivo de texto, igual que visitar una página web cualquiera. Si no hay conexión a
internet o esa comprobación falla, la extensión sigue funcionando con normalidad; no
se bloquea nada por no poder comprobarlo.

## Permisos que pide la extensión, y por qué

- **Acceso a x.com / twitter.com**: para poder abrir los perfiles y el buscador y leer
  los tweets.
- **Pestañas y ventanas (`tabs`, `scripting`)**: para abrir esas pestañas en segundo
  plano y leer su contenido.
- **Descargas (`downloads`)**: para guardar el archivo final en tu carpeta de
  Descargas.
- **Almacenamiento (`storage`)**: para recordar tus listas, programaciones y
  preferencias en tu propio ordenador.
- **Alarmas (`alarms`)**: para poder ejecutar las programaciones a la hora que tú
  elijas.
- **Notificaciones (`notifications`)**: para avisarte cuando termina una búsqueda
  programada.

## Tus datos, bajo tu control

Como todo se queda en tu ordenador, borrar los archivos generados, las listas o la
extensión entera es lo único que hace falta para eliminar cualquier rastro de su uso.
No hay ninguna cuenta en la nube que cerrar ni ningún dato que pedir que se borre en
otro sitio, porque nunca salió de tu equipo.

## Contacto

Si tienes dudas sobre esta política o sobre cómo funciona la extensión, contacta con
la persona o tienda a la que se la compraste.
